# Import blueprints
from app.routes import main, auth, subscription
